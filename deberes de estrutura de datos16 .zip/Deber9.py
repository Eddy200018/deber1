class Nueve:
    def _init_(self):
        pass
 
    def sumaCuadradaos(self):
        acu=0
        cont=1
        n=0
 
        while cont < 101 :
            n=(cont)**2 
            acu+=n
            cont=cont+1
        print(acu)
 
entero = Nueve()
entero.sumaCuadradaos()