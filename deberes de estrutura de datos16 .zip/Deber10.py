class diez:
    def _init_(self):
        pass
 
    def Examen(self):
 
        exa1= float(input("Ingrese la nota del examen uno: "))
        exa2= float(input("Ingrese la nota del examen dos: "))
 
        if exa1 > 79 and exa2 > 79:
            print("Aceptado")
        else:
            print("Rechazado")
 
aspirante = diez()
aspirante.Examen