#Elabore pseudocódigo para el caso en que se desean escribir los números 
# del 1 al 100

class Ejemwhile:
    def _init_(self):
        pass
    
    def pseudo (self):
        Numero= 1
        while Numero <= 100 :
            print("Su numero ha sido ingresado con exito: "+str(Numero))
            Numero= Numero+1
        print ("Termino la ejecucion")
        
      
        
        
        
            
ejewhile= Ejemwhile()
ejewhile.pseudo()