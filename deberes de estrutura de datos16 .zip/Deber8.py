#Leer tres números enteros diferentes entre sí y determinar el número mayor
# de los tres.

class Tarea:
    def _init_(self):
        pass
    
    def numayor (self): 
        Nm1= int(input("Digite su primer numero: "))
        Nm2= int(input("Digite su segundo numero: "))
        Nm3= int(input("Digite su tercer numero: "))
        if Nm1 > Nm2 and Nm1 > Nm3 :
            Num_mayor= (Nm1)
        elif Nm2 > Nm3:
            Num_mayor= (Nm2)
        else:
            Num_mayor= (Nm3)
        print("El numero mayor entre los tres numeros es el : ",Num_mayor)
            
eje= Tarea()
eje.numayor()